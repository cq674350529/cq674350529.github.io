#!/usr/bin/env python

import os
import time
import subprocess
import ConfigParser


def custom_func(binary_name, binary_path, binary_hash, result_file, config_file):
    # read config
    config = ConfigParser.ConfigParser()
    config.read(config_file)
    ida_engine_path = os.path.join(config.get('ida_config', 'IDA_ENGINE32_PATH'))
    ida_custom_script = config.get('scripts_config', 'IDA_CUSTOM_SCRIPT')
    idb_store_path = os.path.join("temp", "%s.idb" % binary_hash)

    if os.path.exists(ida_engine_path):
        # reference: https://www.hex-rays.com/products/ida/support/idadoc/417.shtml
        # load binary with ida
        cmd = '"%s" -A -B -p%s -o%s %s' % (ida_engine_path, "metapc", idb_store_path, binary_path)
        subprocess.call(cmd)

        # wait idb to be generated
        while True:
            if os.path.exists(idb_store_path):
                break
            else:
                time.sleep(1)

        # execute idapython script
        cmd = '"%s" -A -S"%s %s %s" %s' % (ida_engine_path, ida_custom_script, binary_name, result_file, idb_store_path)
        subprocess.call(cmd)
