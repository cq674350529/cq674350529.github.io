#!/usr/bin/env python

from idc import *
from idautils import *
from idaapi import *

        
def main():
    arg1 = ARGV[1]  # binary_name
    arg2 = ARGV[2]  # result_file
    
    # do what you want
    # ...


main()

# exit IDA
idc.Exit(0)