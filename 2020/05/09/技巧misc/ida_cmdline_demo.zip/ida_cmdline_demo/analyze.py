#!/usr/bin/env python

import os
import sys
import argparse
import hashlib
import subprocess
from ida_scripts import ida_utils


def get_file_hash(file):
    return hashlib.md5(open(file, 'rb').read()).hexdigest()


def custom_task(binary_path, binary_hash, result_path, config_path):
    binary_name = os.path.basename(binary_path)
    ida_utils.custom_func(binary_name, binary_path, binary_hash, result_path, config_path)

    
def main():
    parser = argparse.ArgumentParser(description="automatic ida cmdline script")
    group = parser.add_mutually_exclusive_group()
    group.add_argument("-d", "--directory", help="directory contains binary")
    group.add_argument("-f", "--file", help="single binary path")
    args = parser.parse_args()

    if args.directory is None and args.file is None:
        print "[-] args missing"
        parser.print_help()
        sys.exit()

    config_path = "./config.conf"
    result_path = "result.json"
    
    if args.file:
        binary_path = args.file
        binary_hash = get_file_hash(binary_path)
        custom_task(binary_path, binary_hash, result_path, config_path)
    else:
        for item in os.listdir(args.directory):
            binary_path = os.path.join(args.directory, item)
            binary_hash = get_file_hash(binary_path)
            custom_task(binary_path, binary_hash, result_path, config_path)
    

if __name__ == "__main__":
    main()
    