#!/usr/bin/env python3

import angr
from angr.procedures.stubs.format_parser import FormatParser

class MyScanf(FormatParser):
    def run(self,fmt):
        addr = self.state.solver.eval(self.arg(1))
        print("input flag addr: %#x" % addr)
        self.state.memory.store(addr, self.state.solver.BVV(b'f',8), endness=self.state.arch.memory_endness)
        self.state.memory.store(addr+1, self.state.solver.BVV(b'l',8), endness=self.state.arch.memory_endness)
        self.state.memory.store(addr+2, self.state.solver.BVV(b'a',8), endness=self.state.arch.memory_endness)
        self.state.memory.store(addr+3, self.state.solver.BVV(b'g',8), endness=self.state.arch.memory_endness)
        self.state.memory.store(addr+4, self.state.solver.BVV(b'{',8), endness=self.state.arch.memory_endness)
        self.state.memory.store(addr+21, self.state.solver.BVV(b'}',8), endness=self.state.arch.memory_endness)
        for i in range(5,20):
            self.state.memory.store(addr+i, self.state.solver.BVS('a%d' % i, 8), endness=self.state.arch.memory_endness)

project= angr.Project('./re1.exe', load_options={'auto_load_libs':False})

start_address = 0x401684
find_address = 0x4017a3
avoid_address = (0x40171b, 0x401749, 0x4017c2)

project.hook_symbol('scanf', MyScanf())
state=project.factory.blank_state(addr=start_address, add_options={angr.options.LAZY_SOLVES})
simgr = project.factory.simulation_manager(state)
simgr.explore(find=find_address, avoid=avoid_address)

if simgr.found:
    find_state = simgr.found[0]

    sp_value = find_state.solver.eval(find_state.regs._sp)
    input_addr = sp_value + 0x11
    print("input flag addr: %#x" % input_addr)

    for i in range(5,20):
        value = find_state.memory.load(input_addr+i, 1)
        find_state.add_constraints(value>=48, value <=127)

    flag = [find_state.solver.eval(find_state.memory.load(input_addr+i, 1)) for i in range(22)]
    print(''.join(map(chr, flag)))