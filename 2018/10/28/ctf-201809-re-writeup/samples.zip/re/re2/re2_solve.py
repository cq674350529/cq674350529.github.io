#!/usr/bin/env python

from collections import defaultdict
import copy

with open('./flag_enc', 'rb') as f:
    dword_601ca0 = f.read()

byte_6010a0_sorted = []
byte_601aa0 = []

index = 0
while index < len(dword_601ca0):
    value = dword_601ca0[index:index+4]
    count = dword_601ca0[index+4:index+8]
    if value[0] != '\xff':
        byte_6010a0_sorted.extend([value[0]] * ord(count[0]))
        index += 8
    else:
        break

index += 4
while index < len(dword_601ca0):
    value = dword_601ca0[index:index+4]
    count = dword_601ca0[index+4:index+8]
    byte_601aa0.extend([value[0]] * ord(count[0]))
    index += 8

# the last item in byte_601aa0 is omitted in original code
byte_601aa0.append('_')

char_dict = defaultdict(list)
for index in xrange(len(byte_6010a0_sorted)):
    char_dict[byte_6010a0_sorted[index]].append(byte_601aa0[index])

def dfs(nextc, key_index, total_char, flags):
    key_index = copy.deepcopy(key_index)
    if total_char == len(byte_6010a0_sorted):
        print flags
        return True

    for key in key_index:
        if key_index[key] == len(char_dict[key]):
            continue

        # use key_index[key] to keep the order of sequence
        if char_dict[key][key_index[key]] == nextc:
            key_index[key] += 1
            if dfs(key, key_index, total_char+1, flags+key):
                return True
            key_index[key] -= 1
    
    return False

key_index = {}
for item in char_dict:
    key_index[item] = 0

for key in key_index:
    dfs(key, key_index, 0, '')